import bcrypt from 'bcryptjs';
import pool from '../config/database.js';

const createAdmin = async () => {
  try {
    const username = 'admin';
    const password = 'YourStrongPassword123!'; // Change this!

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    await pool.query(
      'INSERT INTO admin_users (username, password_hash) VALUES (?, ?) ON DUPLICATE KEY UPDATE password_hash = ?',
      [username, hashedPassword, hashedPassword]
    );

    console.log('✅ Admin user created successfully');
    console.log('Username:', username);
    console.log('Password:', password);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error creating admin:', error);
    process.exit(1);
  }
};

createAdmin();