const express = require('express');
const router = express.Router();
const {
    // Public
    submitQuotation,
    trackQuotation,
    
    // Admin
    getAllQuotations,
    getQuotationById,
    updateQuotationStatus,
    updateQuotationNotes,
    convertToInvoice,
    deleteQuotation,
    
    // Notifications
    getNotifications,
    markNotificationRead,
    markAllNotificationsRead
} = require('../controllers/quotationController');
const { protect } = require('../middleware/authMiddleware');

// ==================== PUBLIC ROUTES ====================

/**
 * @route   POST /api/quotations/public
 * @desc    Submit a new quotation from cart
 * @access  Public
 */
router.post('/public', submitQuotation);

/**
 * @route   GET /api/quotations/track/:reference
 * @desc    Track quotation by reference number
 * @access  Public
 */
router.get('/track/:reference', trackQuotation);

// ==================== ADMIN ROUTES ====================
// All routes below require authentication

/**
 * @route   GET /api/quotations
 * @desc    Get all quotations with filters
 * @access  Private
 */
router.get('/', protect, getAllQuotations);

/**
 * @route   GET /api/quotations/notifications
 * @desc    Get all notifications
 * @access  Private
 */
router.get('/notifications', protect, getNotifications);

/**
 * @route   POST /api/quotations/notifications/:id/read
 * @desc    Mark notification as read
 * @access  Private
 */
router.post('/notifications/:id/read', protect, markNotificationRead);

/**
 * @route   POST /api/quotations/notifications/read-all
 * @desc    Mark all notifications as read
 * @access  Private
 */
router.post('/notifications/read-all', protect, markAllNotificationsRead);

/**
 * @route   GET /api/quotations/:id
 * @desc    Get single quotation by ID
 * @access  Private
 */
router.get('/:id', protect, getQuotationById);

/**
 * @route   PUT /api/quotations/:id/status
 * @desc    Update quotation status
 * @access  Private
 */
router.put('/:id/status', protect, updateQuotationStatus);

/**
 * @route   PUT /api/quotations/:id/notes
 * @desc    Update admin notes
 * @access  Private
 */
router.put('/:id/notes', protect, updateQuotationNotes);

/**
 * @route   POST /api/quotations/:id/convert-to-invoice
 * @desc    Convert quotation to invoice
 * @access  Private
 */
router.post('/:id/convert-to-invoice', protect, convertToInvoice);

/**
 * @route   DELETE /api/quotations/:id
 * @desc    Delete quotation
 * @access  Private
 */
router.delete('/:id', protect, deleteQuotation);

module.exports = router;