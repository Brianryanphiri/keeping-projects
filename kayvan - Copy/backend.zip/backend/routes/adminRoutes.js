const express = require('express');
const router = express.Router();

// Protected routes (admin only)
router.get('/stats', (req, res) => {
  res.json({
    products: 0,
    projects: 0,
    quotations: 0,
    invoices: 0
  });
});

module.exports = router;