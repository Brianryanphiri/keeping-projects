const express = require('express');
const router = express.Router();

// Public routes
router.get('/published', (req, res) => {
  res.json({ message: 'Published services route working' });
});

router.get('/', (req, res) => {
  res.json({ message: 'Services route working' });
});

router.get('/:id', (req, res) => {
  res.json({ message: `Get service ${req.params.id}` });
});

// Protected routes (admin only)
router.post('/', (req, res) => {
  res.json({ message: 'Create service' });
});

router.put('/:id', (req, res) => {
  res.json({ message: `Update service ${req.params.id}` });
});

router.delete('/:id', (req, res) => {
  res.json({ message: `Delete service ${req.params.id}` });
});

module.exports = router;