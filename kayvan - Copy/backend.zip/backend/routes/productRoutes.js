const express = require('express');
const router = express.Router();

// ==================== TEST ROUTE ====================
// Add this at the VERY TOP - this will confirm the routes are loaded
router.get('/test', (req, res) => {
  res.json({ 
    message: '✅ Projects API is working!',
    timestamp: new Date().toISOString(),
    baseUrl: req.baseUrl,
    originalUrl: req.originalUrl,
    routes: {
      getAll: 'GET /',
      getPublished: 'GET /published',
      getFeatured: 'GET /featured',
      getByCategory: 'GET /category/:category',
      getStats: 'GET /stats',
      getBySlug: 'GET /slug/:slug',
      getById: 'GET /:id',
      create: 'POST /',
      update: 'PUT /:id',
      delete: 'DELETE /:id',
      uploadImage: 'POST /upload-image'
    }
  });
});

// ==================== PUBLIC ROUTES ====================

/**
 * @route   GET /api/projects/published
 * @desc    Get all published projects for public portfolio
 * @access  Public
 */
router.get('/published', async (req, res) => {
  try {
    // Return mock data for now - replace with database query later
    const mockProjects = [
      {
        id: 1,
        title: 'Industrial Epoxy Flooring for Manufacturing Plant',
        slug: 'industrial-epoxy-manufacturing-plant',
        short_description: 'Complete epoxy flooring installation for a 50,000 sq ft automotive manufacturing facility',
        description: 'This project involved installing heavy-duty epoxy flooring for a major automotive parts manufacturer. The facility required a durable, chemical-resistant, and anti-static flooring system.',
        client_name: 'ABC Automotive Parts',
        category: 'Industrial',
        subcategory: 'Manufacturing',
        location: 'Detroit, Michigan',
        completion_date: '2024-01-15',
        duration: '3 weeks',
        surface_area: '50,000 sq ft',
        project_value: 175000,
        featured_image: null,
        is_featured: true,
        specs: ['3mm thickness', 'Anti-static', 'Chemical resistant'],
        materials_used: ['Epoxy Primer', 'Anti-static Epoxy', 'Quartz Sand'],
        created_at: '2024-01-15T00:00:00.000Z'
      },
      {
        id: 2,
        title: 'Healthcare Facility Epoxy Installation',
        slug: 'healthcare-facility-epoxy',
        short_description: 'Anti-microbial epoxy flooring for a major hospital renovation',
        description: 'Installation of anti-microbial epoxy flooring system for City General Hospital. The project required strict hygiene standards and minimal disruption to hospital operations.',
        client_name: 'City General Hospital',
        category: 'Healthcare',
        subcategory: 'Hospital',
        location: 'Chicago, Illinois',
        completion_date: '2023-11-20',
        duration: '4 weeks',
        surface_area: '25,000 sq ft',
        project_value: 95000,
        featured_image: null,
        is_featured: false,
        specs: ['Anti-microbial', 'Slip-resistant', 'Easy to clean'],
        materials_used: ['Medical grade epoxy', 'Polyurethane topcoat'],
        created_at: '2023-11-20T00:00:00.000Z'
      },
      {
        id: 3,
        title: 'Commercial Showroom Epoxy Flooring',
        slug: 'commercial-showroom-epoxy',
        short_description: 'Decorative metallic epoxy flooring for luxury car showroom',
        description: 'High-end decorative metallic epoxy flooring system for a premium automotive dealership. The floor needed to be visually stunning while withstanding heavy vehicle traffic.',
        client_name: 'Luxury Motors',
        category: 'Commercial',
        subcategory: 'Showroom',
        location: 'Los Angeles, California',
        completion_date: '2024-02-10',
        duration: '2 weeks',
        surface_area: '15,000 sq ft',
        project_value: 65000,
        featured_image: null,
        is_featured: true,
        specs: ['Metallic finish', 'High gloss', 'UV stable'],
        materials_used: ['Metallic epoxy', 'Clear topcoat'],
        created_at: '2024-02-10T00:00:00.000Z'
      }
    ];
    
    res.json(mockProjects);
  } catch (error) {
    console.error('Error in /published:', error);
    res.status(500).json({ message: 'Error fetching projects', error: error.message });
  }
});

/**
 * @route   GET /api/projects/featured
 * @desc    Get featured projects for homepage
 * @access  Public
 */
router.get('/featured', async (req, res) => {
  try {
    const mockFeatured = [
      {
        id: 1,
        title: 'Industrial Epoxy Flooring for Manufacturing Plant',
        slug: 'industrial-epoxy-manufacturing-plant',
        short_description: 'Complete epoxy flooring installation for a 50,000 sq ft automotive manufacturing facility',
        category: 'Industrial',
        location: 'Detroit, Michigan',
        featured_image: null,
        client_name: 'ABC Automotive Parts'
      },
      {
        id: 3,
        title: 'Commercial Showroom Epoxy Flooring',
        slug: 'commercial-showroom-epoxy',
        short_description: 'Decorative metallic epoxy flooring for luxury car showroom',
        category: 'Commercial',
        location: 'Los Angeles, California',
        featured_image: null,
        client_name: 'Luxury Motors'
      }
    ];
    res.json(mockFeatured);
  } catch (error) {
    console.error('Error in /featured:', error);
    res.status(500).json({ message: 'Error fetching featured projects' });
  }
});

/**
 * @route   GET /api/projects/category/:category
 * @desc    Get projects by category
 * @access  Public
 */
router.get('/category/:category', async (req, res) => {
  try {
    const { category } = req.params;
    const filtered = [
      {
        id: 1,
        title: 'Industrial Epoxy Flooring for Manufacturing Plant',
        slug: 'industrial-epoxy-manufacturing-plant',
        category: 'Industrial',
        location: 'Detroit, Michigan'
      }
    ].filter(p => p.category === category);
    
    res.json(filtered);
  } catch (error) {
    console.error('Error in /category:', error);
    res.status(500).json({ message: 'Error fetching projects by category' });
  }
});

/**
 * @route   GET /api/projects/stats
 * @desc    Get project statistics
 * @access  Public
 */
router.get('/stats', async (req, res) => {
  try {
    res.json({
      total_projects: 3,
      published_projects: 3,
      featured_projects: 2,
      total_categories: 3,
      avg_project_value: 111666,
      max_project_value: 175000,
      first_project_date: '2023-11-20',
      latest_project_date: '2024-02-10',
      by_category: [
        { category: 'Industrial', count: 1, avg_value: 175000 },
        { category: 'Healthcare', count: 1, avg_value: 95000 },
        { category: 'Commercial', count: 1, avg_value: 65000 }
      ]
    });
  } catch (error) {
    console.error('Error in /stats:', error);
    res.status(500).json({ message: 'Error fetching project stats' });
  }
});

/**
 * @route   GET /api/projects/slug/:slug
 * @desc    Get single project by SEO-friendly slug
 * @access  Public
 */
router.get('/slug/:slug', async (req, res) => {
  try {
    const { slug } = req.params;
    
    const projects = {
      'industrial-epoxy-manufacturing-plant': {
        id: 1,
        title: 'Industrial Epoxy Flooring for Manufacturing Plant',
        slug: 'industrial-epoxy-manufacturing-plant',
        short_description: 'Complete epoxy flooring installation for a 50,000 sq ft automotive manufacturing facility',
        description: 'This project involved installing heavy-duty epoxy flooring for a major automotive parts manufacturer. The facility required a durable, chemical-resistant, and anti-static flooring system to withstand heavy machinery, forklift traffic, and exposure to oils and chemicals. We installed a 3-layer epoxy system with anti-static properties and quartz sand broadcast for enhanced slip resistance.',
        client_name: 'ABC Automotive Parts',
        client_industry: 'Automotive Manufacturing',
        category: 'Industrial',
        subcategory: 'Manufacturing',
        location: 'Detroit, Michigan',
        address: '123 Industrial Parkway',
        city: 'Detroit',
        country: 'USA',
        completion_date: '2024-01-15',
        duration: '3 weeks',
        duration_days: 21,
        team_size: '6 installers',
        surface_area: '50,000 sq ft',
        project_value: 175000,
        specs: ['3mm thickness', 'Anti-static', 'Chemical resistant', 'High-traction', '-30°C to 120°C temperature range'],
        materials_used: ['Epoxy Primer', 'Anti-static Epoxy', 'Quartz Sand', 'Polyurethane Topcoat'],
        challenges: 'The client needed a flooring solution that could withstand heavy forklift traffic (up to 10,000 lbs), resist hydraulic fluid and oil spills, and prevent static buildup that could damage sensitive electronic components.',
        solution: 'We installed a specialized anti-static epoxy system with copper grounding strips every 20 feet. The floor was designed with a slight slope for proper drainage and featured broadcast quartz for enhanced slip resistance.',
        results: ['40% reduction in floor maintenance costs', 'Zero static-related equipment failures', '5-year warranty provided', 'Completed 3 days ahead of schedule'],
        is_featured: true,
        created_at: '2024-01-15T00:00:00.000Z'
      },
      'healthcare-facility-epoxy': {
        id: 2,
        title: 'Healthcare Facility Epoxy Installation',
        slug: 'healthcare-facility-epoxy',
        short_description: 'Anti-microbial epoxy flooring for a major hospital renovation',
        description: 'Installation of anti-microbial epoxy flooring system for City General Hospital. The project required strict hygiene standards and minimal disruption to hospital operations.',
        client_name: 'City General Hospital',
        client_industry: 'Healthcare',
        category: 'Healthcare',
        subcategory: 'Hospital',
        location: 'Chicago, Illinois',
        completion_date: '2023-11-20',
        duration: '4 weeks',
        surface_area: '25,000 sq ft',
        project_value: 95000,
        specs: ['Anti-microbial', 'Slip-resistant', 'Easy to clean'],
        materials_used: ['Medical grade epoxy', 'Polyurethane topcoat'],
        is_featured: false,
        created_at: '2023-11-20T00:00:00.000Z'
      },
      'commercial-showroom-epoxy': {
        id: 3,
        title: 'Commercial Showroom Epoxy Flooring',
        slug: 'commercial-showroom-epoxy',
        short_description: 'Decorative metallic epoxy flooring for luxury car showroom',
        description: 'High-end decorative metallic epoxy flooring system for a premium automotive dealership. The floor needed to be visually stunning while withstanding heavy vehicle traffic.',
        client_name: 'Luxury Motors',
        client_industry: 'Automotive Retail',
        category: 'Commercial',
        subcategory: 'Showroom',
        location: 'Los Angeles, California',
        completion_date: '2024-02-10',
        duration: '2 weeks',
        surface_area: '15,000 sq ft',
        project_value: 65000,
        specs: ['Metallic finish', 'High gloss', 'UV stable'],
        materials_used: ['Metallic epoxy', 'Clear topcoat'],
        is_featured: true,
        created_at: '2024-02-10T00:00:00.000Z'
      }
    };
    
    if (projects[slug]) {
      return res.json(projects[slug]);
    }
    
    res.status(404).json({ message: 'Project not found' });
  } catch (error) {
    console.error('Error in /slug/:slug:', error);
    res.status(500).json({ message: 'Error fetching project', error: error.message });
  }
});

/**
 * @route   GET /api/projects/:id
 * @desc    Get single project by ID (legacy)
 * @access  Public
 */
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Redirect to slug-based lookup or return mock
    const projects = {
      '1': 'industrial-epoxy-manufacturing-plant',
      '2': 'healthcare-facility-epoxy',
      '3': 'commercial-showroom-epoxy'
    };
    
    if (projects[id]) {
      // Redirect to slug endpoint
      const [project] = await new Promise((resolve) => {
        setTimeout(() => {
          resolve([{
            id: parseInt(id),
            title: projects[id] === 'industrial-epoxy-manufacturing-plant' ? 'Industrial Epoxy Flooring for Manufacturing Plant' :
                   projects[id] === 'healthcare-facility-epoxy' ? 'Healthcare Facility Epoxy Installation' :
                   'Commercial Showroom Epoxy Flooring',
            slug: projects[id]
          }]);
        }, 100);
      });
      return res.json(project);
    }
    
    res.status(404).json({ message: 'Project not found' });
  } catch (error) {
    console.error('Error in /:id:', error);
    res.status(500).json({ message: 'Error fetching project' });
  }
});

// ==================== ADMIN ROUTES ====================
// These will be protected with auth middleware later

/**
 * @route   GET /api/projects
 * @desc    Get all projects (including drafts) - Admin only
 * @access  Private (temporarily public for testing)
 */
router.get('/', async (req, res) => {
  try {
    const mockAllProjects = [
      {
        id: 1,
        title: 'Industrial Epoxy Flooring for Manufacturing Plant',
        slug: 'industrial-epoxy-manufacturing-plant',
        category: 'Industrial',
        client_name: 'ABC Automotive Parts',
        is_published: true,
        is_featured: true,
        created_at: '2024-01-15T00:00:00.000Z'
      },
      {
        id: 2,
        title: 'Healthcare Facility Epoxy Installation',
        slug: 'healthcare-facility-epoxy',
        category: 'Healthcare',
        client_name: 'City General Hospital',
        is_published: true,
        is_featured: false,
        created_at: '2023-11-20T00:00:00.000Z'
      },
      {
        id: 3,
        title: 'Commercial Showroom Epoxy Flooring',
        slug: 'commercial-showroom-epoxy',
        category: 'Commercial',
        client_name: 'Luxury Motors',
        is_published: true,
        is_featured: true,
        created_at: '2024-02-10T00:00:00.000Z'
      },
      {
        id: 4,
        title: 'Warehouse Epoxy Flooring (Draft)',
        slug: 'warehouse-epoxy-flooring-draft',
        category: 'Warehouse',
        client_name: 'Logistics Corp',
        is_published: false,
        is_featured: false,
        created_at: '2024-02-15T00:00:00.000Z'
      }
    ];
    res.json(mockAllProjects);
  } catch (error) {
    console.error('Error in GET /:', error);
    res.status(500).json({ message: 'Error fetching projects' });
  }
});

/**
 * @route   POST /api/projects
 * @desc    Create a new project - Admin only
 * @access  Private
 */
router.post('/', (req, res) => {
  try {
    const newProject = {
      id: Date.now(),
      ...req.body,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    res.status(201).json({ 
      message: 'Project created successfully', 
      project: newProject 
    });
  } catch (error) {
    console.error('Error in POST /:', error);
    res.status(500).json({ message: 'Error creating project' });
  }
});

/**
 * @route   PUT /api/projects/:id
 * @desc    Update a project - Admin only
 * @access  Private
 */
router.put('/:id', (req, res) => {
  try {
    res.json({ 
      message: `Project ${req.params.id} updated successfully`,
      project: {
        id: parseInt(req.params.id),
        ...req.body,
        updated_at: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('Error in PUT /:id:', error);
    res.status(500).json({ message: 'Error updating project' });
  }
});

/**
 * @route   DELETE /api/projects/:id
 * @desc    Delete a project - Admin only
 * @access  Private
 */
router.delete('/:id', (req, res) => {
  try {
    res.json({ 
      message: `Project ${req.params.id} deleted successfully` 
    });
  } catch (error) {
    console.error('Error in DELETE /:id:', error);
    res.status(500).json({ message: 'Error deleting project' });
  }
});

/**
 * @route   POST /api/projects/upload-image
 * @desc    Upload a project image - Admin only
 * @access  Private
 */
router.post('/upload-image', (req, res) => {
  try {
    // Mock image upload response
    const mockImageUrl = `/uploads/projects/mock-image-${Date.now()}.jpg`;
    res.json({ 
      message: 'Image uploaded successfully',
      url: mockImageUrl 
    });
  } catch (error) {
    console.error('Error in /upload-image:', error);
    res.status(500).json({ message: 'Error uploading image' });
  }
});

module.exports = router;