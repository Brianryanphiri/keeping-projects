const express = require('express');
const { 
  login, 
  register, 
  getMe, 
  logout,
  changePassword,
  verifyToken,
  resetPassword,
  getAllUsers,
  updateUser,
  deleteUser
} = require('../controllers/authController');
const { protect, isAdmin } = require('../middleware/authMiddleware');

const router = express.Router();

// ============ PUBLIC ROUTES ============
router.post('/login', login);
router.post('/register', register); // Remove after creating first admin

// ============ PROTECTED ROUTES ============
router.get('/me', protect, getMe);
router.post('/logout', protect, logout);
router.put('/change-password', protect, changePassword);
router.get('/verify', protect, verifyToken);

// ============ ADMIN ONLY ROUTES ============
router.get('/users', protect, isAdmin, getAllUsers);
router.post('/reset-password', protect, isAdmin, resetPassword);
router.put('/users/:id', protect, isAdmin, updateUser);
router.delete('/users/:id', protect, isAdmin, deleteUser);

module.exports = router;