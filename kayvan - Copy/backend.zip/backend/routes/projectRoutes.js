const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const {
    getAllProjects,
    getPublishedProjects,
    getProjectBySlug,
    createProject,
    updateProject,
    deleteProject,
    uploadImage,
    getFeaturedProjects,
    getProjectsByCategory,
    getProjectStats
} = require('../controllers/projectController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

// ==================== FILE UPLOAD CONFIGURATION ====================

// Ensure upload directory exists
const uploadDir = path.join(__dirname, '../../uploads/projects/');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
    console.log('📁 Created projects upload directory');
}

// Configure multer for project image uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        cb(null, `project-${uniqueSuffix}${ext}`);
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: (req, file, cb) => {
        const allowedTypes = /jpeg|jpg|png|gif|webp/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);
        
        if (mimetype && extname) {
            return cb(null, true);
        } else {
            cb(new Error('Only image files are allowed (jpeg, jpg, png, gif, webp)'));
        }
    }
});

// ==================== PUBLIC ROUTES ====================
// These routes are accessible to everyone (no authentication required)

/**
 * @route   GET /api/projects/published
 * @desc    Get all published projects for public portfolio
 * @access  Public
 */
router.get('/published', getPublishedProjects);

/**
 * @route   GET /api/projects/featured
 * @desc    Get featured projects for homepage
 * @access  Public
 */
router.get('/featured', getFeaturedProjects);

/**
 * @route   GET /api/projects/category/:category
 * @desc    Get projects by category
 * @access  Public
 */
router.get('/category/:category', getProjectsByCategory);

/**
 * @route   GET /api/projects/stats
 * @desc    Get project statistics
 * @access  Public
 */
router.get('/stats', getProjectStats);

/**
 * @route   GET /api/projects/slug/:slug
 * @desc    Get single project by SEO-friendly slug
 * @access  Public
 */
router.get('/slug/:slug', getProjectBySlug);

// ==================== ADMIN ROUTES ====================
// All routes below require authentication and admin privileges

/**
 * @route   GET /api/projects
 * @desc    Get all projects (including drafts) - Admin only
 * @access  Private/Admin
 */
router.get('/', protect, getAllProjects);

/**
 * @route   POST /api/projects
 * @desc    Create a new project - Admin only
 * @access  Private/Admin
 */
router.post('/', protect, createProject);

/**
 * @route   PUT /api/projects/:id
 * @desc    Update a project - Admin only
 * @access  Private/Admin
 */
router.put('/:id', protect, updateProject);

/**
 * @route   DELETE /api/projects/:id
 * @desc    Delete a project - Admin only
 * @access  Private/Admin
 */
router.delete('/:id', protect, deleteProject);

/**
 * @route   POST /api/projects/upload-image
 * @desc    Upload a project image - Admin only
 * @access  Private/Admin
 */
router.post('/upload-image', protect, upload.single('image'), uploadImage);

// ==================== ERROR HANDLING ====================

// Handle multer errors
router.use((error, req, res, next) => {
    if (error instanceof multer.MulterError) {
        if (error.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({
                message: 'File too large. Maximum size is 5MB'
            });
        }
        return res.status(400).json({
            message: 'File upload error',
            error: error.message
        });
    }
    next(error);
});

module.exports = router;