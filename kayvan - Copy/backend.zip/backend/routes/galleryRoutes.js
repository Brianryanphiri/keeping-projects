const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const {
    // Public
    getPublishedItems,
    getFeaturedItems,
    getItemBySlug,
    getCategories,
    getGalleryStats,
    toggleLike,
    getLikeStatus,
    incrementDownload,
    getItemsByProject,
    
    // Admin
    getAllItems,
    createItem,
    updateItem,
    deleteItem,
    uploadImage,
    bulkUpdateItems
} = require('../controllers/galleryController');
const { protect } = require('../middleware/authMiddleware');

// ==================== FILE UPLOAD CONFIGURATION ====================

// Ensure upload directory exists
const uploadDir = path.join(__dirname, '../../uploads/gallery/');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
    console.log('📁 Created gallery upload directory');
}

// Configure multer for gallery image uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        cb(null, `gallery-${uniqueSuffix}${ext}`);
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: (req, file, cb) => {
        const allowedTypes = /jpeg|jpg|png|gif|webp/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);
        
        if (mimetype && extname) {
            return cb(null, true);
        } else {
            cb(new Error('Only image files are allowed (jpeg, jpg, png, gif, webp)'));
        }
    }
});

// ==================== PUBLIC ROUTES ====================

/**
 * @route   GET /api/gallery/published
 * @desc    Get all published gallery items
 * @access  Public
 */
router.get('/published', getPublishedItems);

/**
 * @route   GET /api/gallery/featured
 * @desc    Get featured gallery items
 * @access  Public
 */
router.get('/featured', getFeaturedItems);

/**
 * @route   GET /api/gallery/categories
 * @desc    Get all categories with counts
 * @access  Public
 */
router.get('/categories', getCategories);

/**
 * @route   GET /api/gallery/stats
 * @desc    Get gallery statistics
 * @access  Public
 */
router.get('/stats', getGalleryStats);

/**
 * @route   GET /api/gallery/item/:slug
 * @desc    Get single gallery item by slug
 * @access  Public
 */
router.get('/item/:slug', getItemBySlug);

/**
 * @route   GET /api/gallery/project/:projectId
 * @desc    Get gallery items by project
 * @access  Public
 */
router.get('/project/:projectId', getItemsByProject);

/**
 * @route   POST /api/gallery/:id/like
 * @desc    Toggle like on gallery item
 * @access  Public
 */
router.post('/:id/like', toggleLike);

/**
 * @route   GET /api/gallery/:id/like-status
 * @desc    Check if user liked gallery item
 * @access  Public
 */
router.get('/:id/like-status', getLikeStatus);

/**
 * @route   POST /api/gallery/:id/download
 * @desc    Increment download count
 * @access  Public
 */
router.post('/:id/download', incrementDownload);

// ==================== ADMIN ROUTES ====================
// All routes below require authentication

/**
 * @route   GET /api/gallery/admin
 * @desc    Get all gallery items (admin)
 * @access  Private
 */
router.get('/admin', protect, getAllItems);

/**
 * @route   POST /api/gallery
 * @desc    Create new gallery item
 * @access  Private
 */
router.post('/', protect, createItem);

/**
 * @route   PUT /api/gallery/:id
 * @desc    Update gallery item
 * @access  Private
 */
router.put('/:id', protect, updateItem);

/**
 * @route   DELETE /api/gallery/:id
 * @desc    Delete gallery item
 * @access  Private
 */
router.delete('/:id', protect, deleteItem);

/**
 * @route   POST /api/gallery/upload
 * @desc    Upload gallery image
 * @access  Private
 */
router.post('/upload', protect, upload.single('image'), uploadImage);

/**
 * @route   POST /api/gallery/bulk-update
 * @desc    Bulk update gallery items
 * @access  Private
 */
router.post('/bulk-update', protect, bulkUpdateItems);

// ==================== ERROR HANDLING ====================

router.use((error, req, res, next) => {
    if (error instanceof multer.MulterError) {
        if (error.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({
                message: 'File too large. Maximum size is 10MB'
            });
        }
        return res.status(400).json({
            message: 'File upload error',
            error: error.message
        });
    }
    next(error);
});

module.exports = router;