const express = require('express');
const router = express.Router();
const {
    // CRUD
    getAllInvoices,
    getInvoiceById,
    getInvoiceByNumber,
    createInvoice,
    updateInvoice,
    deleteInvoice,
    
    // Payments
    recordPayment,
    getPayments,
    
    // Actions
    markAsSent,
    markAsPaid,
    duplicateInvoice,
    
    // Stats
    getInvoiceStats
} = require('../controllers/invoiceController');
const { protect } = require('../middleware/authMiddleware');

// ==================== ALL ROUTES REQUIRE AUTHENTICATION ====================

/**
 * @route   GET /api/invoices/stats
 * @desc    Get invoice statistics
 * @access  Private
 */
router.get('/stats', protect, getInvoiceStats);

/**
 * @route   GET /api/invoices/number/:invoiceNumber
 * @desc    Get invoice by invoice number
 * @access  Private
 */
router.get('/number/:invoiceNumber', protect, getInvoiceByNumber);

/**
 * @route   GET /api/invoices/:id/payments
 * @desc    Get payment history for an invoice
 * @access  Private
 */
router.get('/:id/payments', protect, getPayments);

/**
 * @route   GET /api/invoices/:id
 * @desc    Get single invoice by ID
 * @access  Private
 */
router.get('/:id', protect, getInvoiceById);

/**
 * @route   GET /api/invoices
 * @desc    Get all invoices with filters
 * @access  Private
 */
router.get('/', protect, getAllInvoices);

/**
 * @route   POST /api/invoices
 * @desc    Create a new invoice
 * @access  Private
 */
router.post('/', protect, createInvoice);

/**
 * @route   POST /api/invoices/:id/payments
 * @desc    Record a payment for an invoice
 * @access  Private
 */
router.post('/:id/payments', protect, recordPayment);

/**
 * @route   POST /api/invoices/:id/send
 * @desc    Mark invoice as sent
 * @access  Private
 */
router.post('/:id/send', protect, markAsSent);

/**
 * @route   POST /api/invoices/:id/mark-paid
 * @desc    Mark invoice as paid
 * @access  Private
 */
router.post('/:id/mark-paid', protect, markAsPaid);

/**
 * @route   POST /api/invoices/:id/duplicate
 * @desc    Duplicate an invoice
 * @access  Private
 */
router.post('/:id/duplicate', protect, duplicateInvoice);

/**
 * @route   PUT /api/invoices/:id
 * @desc    Update an invoice
 * @access  Private
 */
router.put('/:id', protect, updateInvoice);

/**
 * @route   DELETE /api/invoices/:id
 * @desc    Delete an invoice (draft only)
 * @access  Private
 */
router.delete('/:id', protect, deleteInvoice);

module.exports = router;